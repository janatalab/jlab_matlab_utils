function pyes=pyesfunction(DeltaLDL,DeltaL,farate)

global faratelist invcumnormlist cumnormlist dprimelist oldprec
%global pastLDL pastDL pastfarate pastcumnorm

prec=1000;

eps=0.0001;
if farate==0
   farate=.01;
end
if DeltaLDL==0
   DeltaLDL=eps;
end

pyes=[];

% Precompute/Initialize the invcumnorm array
if(isempty(faratelist) | isempty(oldprec) | prec~=oldprec)
   oldprec=prec;
	faratelist=[0:.01:.50];
   invcumnormlist=invcumnorm(faratelist);
   dprimelist=[-4:1/prec:4];
   dprimelist=round(dprimelist*prec)/prec;
   cumnormlist=cumnorm(dprimelist);
	cumnormlist(cumnormlist==1)=cumnormlist(cumnormlist==1)-eps;
	cumnormlist(cumnormlist==0)=cumnormlist(cumnormlist==0)+eps;
end

% If we have this cumnorm precomputed, use it. Otherwise, compute, store, and use...
%for i=1:length(DeltaL)
%	tmpidx=find(pastLDL==DeltaLDL & pastDL==DeltaL(i) & pastfarate==farate);
%	if isempty(tmpidx)
%  	tmpidx=length(pastLDL)+1;
%      pastLDL(end+1)=DeltaLDL;
%      pastDL(end+1)=DeltaL(i);
%      pastfarate(end+1)=farate;
%      pastcumnorm(end+1)=cumnorm((DeltaL(i)./DeltaLDL)+invcumnormlist(faratelist==(round(farate*100)/100)));
%   end
%   pyes(end+1)=pastcumnorm(tmpidx);
%end

   
%pyes=cumnorm((DeltaL./DeltaLDL)+invcumnorm(farate));

% Compute the "dprime" for the cumnorm, and round it to be at the precision of our precomputed table
thisdprime=round(prec*((DeltaLDL./DeltaL)+invcumnormlist(faratelist==(round(farate*100)/100))))/prec;
thisdprime(thisdprime<-4)=-4;
thisdprime(thisdprime>4)=4;
pyes=cumnormlist(round((1+((thisdprime+4)*prec))));

%pyes=cumnorm((DeltaL./DeltaLDL)+invcumnormlist(faratelist==(round(farate*100)/100)));

%pyes(pyes==1)=pyes(pyes==1)-eps; %pyes(pyes==0)=pyes(pyes==0)+eps;